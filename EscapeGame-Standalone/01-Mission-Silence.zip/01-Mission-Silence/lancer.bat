@echo off
rem Mission Silence - lancement autonome (Windows)
rem Aucune installation : un runtime Node.js portable peut etre embarque dans runtime\.
setlocal
cd /d "%~dp0"

set NODE=node
if exist "runtime\node.exe" set NODE=runtime\node.exe

"%NODE%" --version >nul 2>nul
if errorlevel 1 (
  echo [ERREUR] Node.js est introuvable.
  echo Placez un runtime Node.js portable dans le dossier "runtime\" ou installez Node.js.
  pause
  exit /b 1
)

echo Demarrage de Mission Silence...
echo   Page : http://localhost:3000
echo   Arret : fermer la fenetre noire ou faites Ctrl+C dedans
echo.
start "Mission Silence" cmd /k "%NODE% server.js"
timeout /t 2 /nobreak >nul
start "" "http://localhost:3000"
