@echo off
rem Spectro Masked - lancement autonome (Windows)
rem Aucune installation : un runtime Node.js portable peut etre embarque dans runtime\.
setlocal
cd /d "%~dp0"

set NODE=node
if exist "runtime\node.exe" set NODE=runtime\node.exe

"%NODE%" --version >nul 2>nul
if errorlevel 1 (
  echo [ERREUR] Node.js est introuvable.
  echo Placez un runtime Node.js portable dans le dossier "runtime\" ou installez Node.js.
  pause
  exit /b 1
)

echo Demarrage de Spectro Masked...
echo   Page : http://localhost:4000
echo   Micro et MIDI : ouvrir la page dans Chrome ou Edge sur CE PC
echo   Arret : fermer la fenetre noire ou faites Ctrl+C dedans
echo.
start "Spectro Masked" cmd /k "%NODE% server.js"
timeout /t 2 /nobreak >nul
start "" "http://localhost:4000"
